
suma.dos.numeros <- function(x, y){
  resultado <- x + y
  return(resultado)
}

suma.tres.numeros <- function(x, y, z){
  resultado <- x + y + z
  return(resultado)
}

resta.dos.numeros <- function(x, y){
  resultado <- x - y
  return(resultado)
}